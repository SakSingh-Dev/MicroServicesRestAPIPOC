/*
 * package com.gene.c360.config;
 * 
 * import javax.sql.DataSource;
 * 
 * import org.springframework.beans.factory.annotation.Qualifier; import
 * org.springframework.boot.autoconfigure.jdbc.DataSourceProperties; import
 * org.springframework.boot.context.properties.ConfigurationProperties; import
 * org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder; import
 * org.springframework.context.annotation.Bean; import
 * org.springframework.context.annotation.Configuration; import
 * org.springframework.context.annotation.Primary; import
 * org.springframework.data.jpa.repository.config.EnableJpaRepositories; import
 * org.springframework.jdbc.core.JdbcTemplate; import
 * org.springframework.orm.jpa.JpaTransactionManager; import
 * org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean; import
 * org.springframework.transaction.PlatformTransactionManager; import
 * org.springframework.transaction.annotation.EnableTransactionManagement;
 * 
 * import jakarta.persistence.EntityManagerFactory;
 * 
 * @Configuration
 * 
 * @EnableTransactionManagement
 * 
 * @EnableJpaRepositories( entityManagerFactoryRef =
 * "mySqlEntityManagerFactory", transactionManagerRef =
 * "mySqlTransactionManager", basePackages = {
 * "com.gene.c360.repositories.batch" }) public class MySqlPrimeBatchDsConfig {
 * 
 * @Primary
 * 
 * @Bean(name="mySqlProperties")
 * 
 * @ConfigurationProperties("spring.datasource") public DataSourceProperties
 * dataSourceProperties() {
 * 
 * return new DataSourceProperties(); }
 * 
 * @Primary
 * 
 * @Bean(name="batchDataSource")
 * 
 * @ConfigurationProperties(prefix = "spring.datasource") public DataSource
 * datasource(@Qualifier("mySqlProperties") DataSourceProperties properties){
 * 
 * return properties.initializeDataSourceBuilder().build(); }
 * 
 * @Primary
 * 
 * @Bean(name="mySqlEntityManagerFactory") public
 * LocalContainerEntityManagerFactoryBean entityManagerFactoryBean
 * (EntityManagerFactoryBuilder builder,
 * 
 * @Qualifier("batchDataSource") DataSource dataSource){
 * 
 * return builder.dataSource(dataSource) .packages("com.gene.c360.entity.batch")
 * .persistenceUnit("mySqldb").build(); }
 * 
 * @Primary
 * 
 * @Bean(name = "mySqlTransactionManager")
 * 
 * @ConfigurationProperties("spring.jpa") public PlatformTransactionManager
 * transactionManager(
 * 
 * @Qualifier("mySqlEntityManagerFactory") EntityManagerFactory
 * entityManagerFactory) {
 * 
 * return new JpaTransactionManager(entityManagerFactory); }
 * 
 * @Bean(name = "batchJdbcTemplate") public JdbcTemplate
 * jdbcTemplate(@Qualifier("batchDataSource") DataSource ds) { return new
 * JdbcTemplate(ds); } }
 */