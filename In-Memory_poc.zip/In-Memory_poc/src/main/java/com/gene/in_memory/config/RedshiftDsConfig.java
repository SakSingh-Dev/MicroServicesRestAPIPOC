/*
 * package com.gene.c360.config;
 * 
 * import javax.sql.DataSource;
 * 
 * import org.springframework.beans.factory.annotation.Qualifier; import
 * org.springframework.boot.autoconfigure.jdbc.DataSourceProperties; import
 * org.springframework.boot.context.properties.ConfigurationProperties; import
 * org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder; import
 * org.springframework.context.annotation.Bean; import
 * org.springframework.context.annotation.Configuration; import
 * org.springframework.data.jpa.repository.config.EnableJpaRepositories; import
 * org.springframework.jdbc.core.JdbcTemplate; import
 * org.springframework.orm.jpa.JpaTransactionManager; import
 * org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean; import
 * org.springframework.transaction.PlatformTransactionManager; import
 * org.springframework.transaction.annotation.EnableTransactionManagement;
 * 
 * import jakarta.persistence.EntityManagerFactory;
 * 
 * @Configuration
 * 
 * @EnableTransactionManagement
 * 
 * @EnableJpaRepositories(entityManagerFactoryRef = "rsEntityManagerFactory",
 * transactionManagerRef = "rsTransactionManager", basePackages = {
 * "com.gene.c360.repositories.rs" }) public class RedshiftDsConfig {
 * 
 * 
 * @Bean(name = "rsProperties")
 * 
 * @ConfigurationProperties("spring.datasource.rs") public DataSourceProperties
 * dataSourceProperties() {
 * 
 * return new DataSourceProperties(); }
 * 
 * 
 * @Bean(name = "rsDatasource")
 * 
 * @ConfigurationProperties(prefix = "spring.datasource.rs") public DataSource
 * datasource(@Qualifier("rsProperties") DataSourceProperties properties) {
 * 
 * return properties.initializeDataSourceBuilder().build(); }
 * 
 * 
 * @Bean(name = "rsEntityManagerFactory") public
 * LocalContainerEntityManagerFactoryBean
 * entityManagerFactoryBean(EntityManagerFactoryBuilder builder,
 * 
 * @Qualifier("rsDatasource") DataSource dataSource) {
 * 
 * return builder.dataSource(dataSource).packages("com.gene.c360.entity.rs").
 * persistenceUnit("redshiftDb").build(); }
 * 
 * 
 * @Bean(name = "rsTransactionManager")
 * 
 * @ConfigurationProperties("spring.jpa") public PlatformTransactionManager
 * transactionManager(
 * 
 * @Qualifier("rsEntityManagerFactory") EntityManagerFactory
 * entityManagerFactory) {
 * 
 * return new JpaTransactionManager(entityManagerFactory); }
 * 
 * @Bean(name = "rsJdbcTemplate") public JdbcTemplate
 * jdbcTemplate1(@Qualifier("rsDatasource") DataSource ds) { return new
 * JdbcTemplate(ds); } }
 */