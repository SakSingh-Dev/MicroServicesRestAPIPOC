package com.gene.in_memory.repository.mysql;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.gene.in_memory.entity.h2.CustomerMaster;


//@Repository
//public interface CustomerMasterRepository extends JpaRepository<CustomerMaster, String> {
//	 @Query(value = "SELECT DISTINCT CM.ID , CM.Name , CM.Flag , \r\n"
//	 		+ "CONCAT_WS(', ', NULLIF(CM.Address1,''),NULLIF(CM.City,''),\r\n"
//	 		+ "CONCAT_WS(' ',  NULLIF(CM.State ,''),NULLIF(CM.Zip  ,''))\r\n"
//	 		+ ") AS Address, cem.EcosystemId as Ecosytem\r\n"
//	 		+ "FROM CUSTOMER_MASTER CM \r\n"
//	 		+ "INNER JOIN CUSTOMER_ECOSYSTEM_MAP cem ON cem.CustomerId  = CM.ID  \r\n"
//	 		+ "AND cem.IsActive ='Y' limit 10", nativeQuery = true)
//	    List<CustomerMaster> fetchAllData();
//	 
//}