package com.gene.in_memory.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gene.in_memory.entity.h2.CustomerMaster;
import com.gene.in_memory.service.SyncRDSToH2ServiceImpl;

@RestController
@RequestMapping("/customer")
public class InMemoryPOCController {
	@Autowired
	private SyncRDSToH2ServiceImpl syncRdsToH2;

	@GetMapping("/list/by-eco")
	public ResponseEntity<?> getCustomerList(@RequestParam List<String> ecosystem) {
		List<CustomerMaster> list = syncRdsToH2.getAllCustomerByEcosystem(ecosystem);
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	@GetMapping("/sync")
	public ResponseEntity<?> syncRDSToH2() {
		syncRdsToH2.transferData();
		return new ResponseEntity<>(new ArrayList(), HttpStatus.OK);
	}
}
