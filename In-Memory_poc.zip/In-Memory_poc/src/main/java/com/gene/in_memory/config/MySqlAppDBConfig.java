
package com.gene.in_memory.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import jakarta.persistence.EntityManagerFactory;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
		entityManagerFactoryRef = "appEntityManagerFactory",
		transactionManagerRef = "appTransactionManager",
		basePackages = {"com.gene.in_memory.repository.mysql"})
public class MySqlAppDBConfig {
	 @Primary
	@Bean(name = "appProperties")
	@ConfigurationProperties("spring.datasource.app")
	public DataSourceProperties dataSourceProperties() {

		return new DataSourceProperties();
	}
    @Primary
	@Bean(name = "appDatasource")
	@ConfigurationProperties(prefix = "spring.datasource.app")
	public DataSource datasource(@Qualifier("appProperties") DataSourceProperties properties) {

		return properties.initializeDataSourceBuilder().build();
	}
    @Primary
	@Bean(name = "appEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean entityManagerFactoryBean(EntityManagerFactoryBuilder builder,
			@Qualifier("appDatasource") DataSource dataSource) {

		return builder.dataSource(dataSource).packages("com.gene.c360.entity.app").persistenceUnit("appDb").build();
	}
    @Primary
	@Bean(name = "appTransactionManager")
	@ConfigurationProperties("spring.jpa")
	public PlatformTransactionManager transactionManager(
			@Qualifier("appEntityManagerFactory") EntityManagerFactory entityManagerFactory) {

		return new JpaTransactionManager(entityManagerFactory);
	}
	 @Bean(name = "appJdbcTemplate")
	 public JdbcTemplate jdbcTemplate(@Qualifier("appDatasource") DataSource ds) {
	  return new JdbcTemplate(ds);
	 }
}
