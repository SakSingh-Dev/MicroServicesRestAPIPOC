package com.gene.in_memory.entity;

public class CustomerMasterBean {

	private String id;

	private String name;
	
	private int flag;

	private String address;

	private String esosystem;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEsosystem() {
		return esosystem;
	}

	public void setEsosystem(String esosystem) {
		this.esosystem = esosystem;
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

}
