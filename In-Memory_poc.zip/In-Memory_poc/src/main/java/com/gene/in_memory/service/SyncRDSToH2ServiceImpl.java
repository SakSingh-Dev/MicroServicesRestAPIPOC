package com.gene.in_memory.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.gene.in_memory.entity.CustomerMasterBean;
import com.gene.in_memory.entity.h2.CustomerMaster;
import com.gene.in_memory.repository.h2.H2Repository;

import jakarta.annotation.PostConstruct;

@Service
public class SyncRDSToH2ServiceImpl {
	@Autowired
	@Qualifier("appJdbcTemplate")
	private JdbcTemplate appJdbcTemplate;

	@Autowired
	private H2Repository h2Repository;

//	@PostConstruct
	public void transferData() {
		List<CustomerMasterBean> allData = this.getAlltheCUstomerData();
		System.out.println("*********************************"+allData.get(0).getName()+allData.get(0).getEsosystem()+"*********"+allData.get(0).getFlag()+"****"+allData.get(0).getId());
		for (CustomerMasterBean entity : allData) {
			CustomerMaster cm = new CustomerMaster();
			cm.setAddress(entity.getAddress());
			cm.setEcosystem(entity.getEsosystem());
			cm.setFlag(entity.getFlag());
			cm.setId(entity.getId());
			cm.setName(entity.getName());
			h2Repository.saveEntity(cm);
		}
	}

	public List<CustomerMasterBean> getAlltheCUstomerData() {
		
		List<CustomerMasterBean> list = new ArrayList<>();
		String sql = "SELECT DISTINCT CM.ID AS id, CM.Name AS name, CM.Flag as flag, CONCAT_WS(', ', NULLIF(CM.Address1,''),NULLIF(CM.City,''),CONCAT_WS(' ',  NULLIF(CM.State ,''),NULLIF(CM.Zip  ,''))) AS address, cem.EcosystemId as esosystem FROM CUSTOMER_MASTER CM INNER JOIN CUSTOMER_ECOSYSTEM_MAP cem ON cem.CustomerId  = CM.ID  AND cem.IsActive ='Y'";
		list = appJdbcTemplate.query(sql, new BeanPropertyRowMapper<>(CustomerMasterBean.class));

		return list;
	}
	
	public List<CustomerMaster> getAllCustomerByEcosystem(List<String> ecosystem){
		try {
		List<CustomerMaster> list = h2Repository.findAllByEcosystem(ecosystem);
		return list;
		}catch(Exception e) {
			System.out.println(e);
		}
		return new ArrayList<CustomerMaster>();
	}

}
