package com.gene.in_memory.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import jakarta.persistence.EntityManagerFactory;

import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
    basePackages = "com.gene.in_memory.repository.h2",
    entityManagerFactoryRef = "h2EntityManagerFactory",
    transactionManagerRef = "h2TransactionManager"
)
public class H2Config {

	@Bean(name = "h2Properties")
	@ConfigurationProperties("spring.datasource.h2")
	public DataSourceProperties dataSourceProperties() {

		return new DataSourceProperties();
	}
	
	@Bean(name = "h2DataSource")
	@ConfigurationProperties(prefix = "spring.datasource.h2")
	public DataSource datasource(@Qualifier("h2Properties") DataSourceProperties properties) {

		return properties.initializeDataSourceBuilder().build();
	}
	
	@Bean(name = "h2EntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean entityManagerFactoryBean(EntityManagerFactoryBuilder builder,
			@Qualifier("h2DataSource") DataSource dataSource) {
    	System.out.println("***************inside eNTITY mANAGER fACTORY************************");

		return builder.dataSource(dataSource).packages("com.gene.in_memory.entity.h2").persistenceUnit("h2Db").build();
	}
	
	/*
	 * @Bean(name = "h2EntityManagerFactory") public
	 * LocalContainerEntityManagerFactoryBean h2EntityManagerFactory(
	 * 
	 * @Qualifier("h2DataSource") DataSource dataSource) { System.out.
	 * println("***************inside eNTITY mANAGER fACTORY************************"
	 * ); LocalContainerEntityManagerFactoryBean em = new
	 * LocalContainerEntityManagerFactoryBean(); em.setDataSource(dataSource);
	 * em.setPackagesToScan("com.gene.in_memory.entity.h2");
	 * em.setJpaVendorAdapter(new HibernateJpaVendorAdapter()); return em; }
	 */

    @Bean(name = "h2TransactionManager")
	@ConfigurationProperties("spring.jpa")
    public PlatformTransactionManager h2TransactionManager(
            @Qualifier("h2EntityManagerFactory") LocalContainerEntityManagerFactoryBean h2EntityManagerFactory) {
        return new JpaTransactionManager(h2EntityManagerFactory.getObject());
    }
    
	/*
	 * @Bean(name = "h2JdbcTemplate") public JdbcTemplate
	 * jdbcTemplate(@Qualifier("h2Datasource") DataSource ds) { return new
	 * JdbcTemplate(ds); }
	 */
}
