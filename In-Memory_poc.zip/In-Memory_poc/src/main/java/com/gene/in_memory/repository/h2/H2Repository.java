package com.gene.in_memory.repository.h2;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.gene.in_memory.entity.CustomerMasterBean;
import com.gene.in_memory.entity.h2.CustomerMaster;

import jakarta.transaction.Transactional;

@Repository
public interface H2Repository extends JpaRepository<CustomerMaster, String> {
	
	@Modifying
	@Transactional
	@Query(value = "INSERT INTO customer_master (id, name,address,ecosystem,flag) VALUES (:#{#entity.id}, :#{#entity.name},:#{#entity.address},:#{#entity.ecosystem},:#{#entity.flag})", nativeQuery = true)
	void saveEntity(CustomerMaster entity);

	@Query("SELECT c FROM CustomerMaster c WHERE c.ecosystem IN :ecosystem")
	List<CustomerMaster> findAllByEcosystem(@Param("ecosystem")  List<String> ecosystem);

}
