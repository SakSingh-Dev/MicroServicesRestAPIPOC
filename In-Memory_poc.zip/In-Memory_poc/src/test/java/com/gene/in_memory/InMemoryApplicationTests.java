package com.gene.in_memory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InMemoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
